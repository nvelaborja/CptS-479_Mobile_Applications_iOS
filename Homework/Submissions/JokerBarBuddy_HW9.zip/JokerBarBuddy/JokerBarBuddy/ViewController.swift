//
//  ViewController.swift
//  JokerBarBuddy
//
//  Created by Nathan VelaBorja on 3/27/17.
//  Copyright © 2017 Nathan VelaBorja. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var getJokeButton: UIButton!
    @IBOutlet weak var jokeLine1: UILabel!
    @IBOutlet weak var jokeLine2: UILabel!
    @IBOutlet weak var jokeLine3: UILabel!
    @IBOutlet weak var jokeAnswer: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func getJokeButtonPressed(_ sender: UIButton) {
        let url = URL(string: "http://www.eecs.wsu.edu/~holder/courses/MAD/hw9/getjoke.php")
        let dataTask = URLSession.shared.dataTask(with: url!, completionHandler: handleResponse)
        dataTask.resume()
    }
    
    func handleResponse(data: Data?, response: URLResponse?, error: Error?) {
        
        if (error != nil) {
            print("Error: \(error!.localizedDescription)")
            return
        }
        
        let httpResponse = response as! HTTPURLResponse
        let statusCode = httpResponse.statusCode
        
        if (statusCode != 200) {
            let msg = HTTPURLResponse.localizedString(forStatusCode: statusCode)
            print("Error: HTTP \(statusCode) error: \(msg)")
            return
        }
        
        if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: []) {
            let jsonDict = jsonObj as! [String: AnyObject]
            let joke = jsonDict["joke"] as! [String: AnyObject]
            let line1 = joke["line1"] as! String
            let line2 = joke["line2"] as! String
            let line3 = joke["line3"] as! String
            let answer = joke["answer"] as! String
            
            // Set labels on UI thread
            DispatchQueue.main.async {
                self.jokeLine1.text = line1
                self.jokeLine2.text = line2
                self.jokeLine3.text = line3
                self.jokeAnswer.text = answer
            }
        }
        else {
            print("Error: Invalid JSON data")
        }
    }
    

}

