//
//  JokeFuViewController.swift
//  JokerBarBuddy
//
//  Created by Nathan VelaBorja on 3/27/17.
//  Copyright © 2017 Nathan VelaBorja. All rights reserved.
//

import UIKit

class JokeFuViewController: UIViewController, UIGestureRecognizerDelegate {

    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var finishLabel: UILabel!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var tryAgainButton: UIButton!
    var dots = [UIView]()
    var startIsValid = false
    var finishIsValid = false
    var lineIsStraight = true
    var attemptFinished = false
    var startPoint = CGPoint()
    let heightThreshold = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Setup pan gesture recognizer
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
        panGestureRecognizer.delegate = self
        self.view.addGestureRecognizer(panGestureRecognizer)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tryAgainPressed(_ sender: UIButton) {
        for dot in dots {
            dot.removeFromSuperview()
        }
        
        tryAgainButton.isHidden = true
        resultImage.image = UIImage()
        startIsValid = false
        finishIsValid = false
        lineIsStraight = true
        attemptFinished = false
    }
    
    func handlePan (recognizer: UIPanGestureRecognizer) {
        let point = recognizer.location(in: self.view)
        if (recognizer.state == .began) {
            if (attemptFinished) {
                return
            }
            
            let dotView = UIView(frame: CGRect(x: point.x, y: point.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            self.view.addSubview(dotView)
            self.dots.append(dotView)
            
            // Check start location
            if (startLabel.frame.contains(point)) {
                startIsValid = true
            }
            
            // Record start point
            startPoint = point
        }
        if (recognizer.state == .changed) {
            if (attemptFinished) {
                return
            }
            
            let dotView = UIView(frame: CGRect(x: point.x, y: point.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            self.view.addSubview(dotView)
            self.dots.append(dotView)
            
            // Check for straight line
            if (point.y < startPoint.y - CGFloat(heightThreshold) || point.y > startPoint.y + CGFloat(heightThreshold)) {
                lineIsStraight = false
            }
        }
        if (recognizer.state == .ended) {
            if (attemptFinished) {
                return
            }
            
            let dotView = UIView(frame: CGRect(x: point.x, y: point.y, width: 5.0, height: 5.0))
            dotView.backgroundColor = UIColor.blue
            self.view.addSubview(dotView)
            self.dots.append(dotView)
            
            // Check end location
            if (finishLabel.frame.contains(point)) {
                finishIsValid = true
            }
            
            if (startIsValid && lineIsStraight && finishIsValid) {
                successFunction()
            }
            else {
                failureFunction()
            }
        }
    }
    
    func successFunction() {
        tryAgainButton.isHidden = false
        resultImage.image = #imageLiteral(resourceName: "Success")
        attemptFinished = true
    }
    
    func failureFunction() {
        tryAgainButton.isHidden = false
        resultImage.image = #imageLiteral(resourceName: "Failure")
        attemptFinished = true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
